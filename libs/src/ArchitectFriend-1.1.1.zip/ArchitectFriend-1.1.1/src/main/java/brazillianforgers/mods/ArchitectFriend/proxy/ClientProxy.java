package brazillianforgers.mods.ArchitectFriend.proxy;

public class ClientProxy extends CommonProxy
{

}
