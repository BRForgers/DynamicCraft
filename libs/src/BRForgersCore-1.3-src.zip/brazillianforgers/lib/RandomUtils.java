package brazillianforgers.lib;

import java.io.File;

import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;

/**
 * Anything that don't have enough to be a separated Helper
 * @author TheFreeHigh
 *
 */
public class RandomUtils {
	public static Configuration getConfig(String pathname)
	{
		return new Configuration(new File(pathname));
	}
	
	public static Configuration getConfig(File file)
    {
    	return new Configuration(file);
    }
    
    public static Configuration getConfig(FMLPreInitializationEvent event)
    {
    	return new Configuration(event.getSuggestedConfigurationFile());
    }
	
	/**
	 * Just in case anyone doesn't know where, I found this on {@link MinecraftForge} class
	 * @param seed The Seed {@link ItemStack} to Be Dropped
	 * @param chance The Chance to be Dropped (Wheat Seeds is 10)
	 */
	public static void addGrassSeed(ItemStack seed, int chance)
	{
		MinecraftForge.addGrassSeed(seed, chance);
	}
}
