package brazillianforgers.lib.RecipeHelper;

import java.util.ArrayList;

import scala.actors.threadpool.Arrays;

public class RecipeHelper {
	public enum FilterMode {
		/**
		 * If any tag is present, it will be kept
		 */
		ANY,
		/**
		 * If all tags are present, it will be kept
		 */
		ALL,
		/**
		 * If any tag isn't present, it will be kept
		 */
		NONE;
	}
	
	/**
	 * Filter all Recipes from Handler. If it have ANY of the tags, it will be kept
	 * @param tags
	 * @return
	 */
	public static Recipe[] filterTags(Recipe[] recipes, FilterMode mode, String... tags)
	{
		ArrayList<Recipe> filtered = new ArrayList<Recipe>();
		
		if (mode == FilterMode.ANY)
		{
			for(Recipe eachRecipe : recipes)
			{
				boolean passed = false;
				for(String tag : tags)
				{
					if(!passed && eachRecipe.doHaveTag(tag))
					{
						filtered.add(eachRecipe);
						passed = true;
					}
				}
			}
		}
		else if (mode == FilterMode.ALL)
		{
			for(Recipe eachRecipe : recipes)
			{
				boolean passed = true;
				for(String tag : tags)
				{
					if(passed && !eachRecipe.doHaveTag(tag))
					{
						passed = false;
					}
				}
				
				if (passed)
				{
					filtered.add(eachRecipe);
				}
			}
		}
		else if (mode == FilterMode.NONE)
		{
			for(Recipe eachRecipe : recipes)
			{
				boolean passed = true;
				for(String tag : tags)
				{
					if(passed && eachRecipe.doHaveTag(tag))
					{
						passed = false;
					}
				}
				
				if (passed)
				{
					filtered.add(eachRecipe);
				}
			}
		}
		
		return filtered.toArray(new Recipe[filtered.size()]);
	}
	
	/**
	 * Register all Recipes in a Array
	 * @param recipes {@link Recipe} Array (Or Single Item)
	 */
	public static void registerAll(Recipe... recipes)
	{
		for (Recipe recipe: recipes) recipe.registerCrafting();
	}
	
	/**
	 * Register all Recipes in ICraftable Objects
	 * @param objects {@link ICraftable} Array (Or Single Item)
	 */
	public static void registerAll(ICraftable... objects)
	{
		for (ICraftable obj: objects) registerAll(obj.getRecipes());
	}
}
