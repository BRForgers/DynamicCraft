package brazillianforgers.lib.RecipeHelper;

import java.util.ArrayList;
import java.util.Arrays;

import brazillianforgers.lib.RecipeHelper.RecipeHelper.FilterMode;

/**
 * RecipeHandler, for use with {@link Recipe}s. Enjoy.
 * @author TheFreeHigh
 *
 */
public class RecipeHandler {
	/**
	 * The Recipes ArrayList. You should not touch it. Directly.
	 */
	protected ArrayList<Recipe> recipes = new ArrayList<Recipe>();
	
	/**
	 * Default Constructor
	 */
	public RecipeHandler() {}
	
	/**
	 * Fast Constructor (Add all recipes to the Handler at the init)
	 * @param recipes {@link Recipe} Array
	 */
	public RecipeHandler(Recipe... recipes) {add(recipes);}
	
	/**
	 * Ultra Fast Constructor (Add all recipes to the Handler at the init)
	 * @param recipes {@link Recipe} Arrays
	 */
	public RecipeHandler(Recipe[]... recipes) {add(recipes);}
	
	/**
	 * Ultra Fast Constructor (Add all recipes to the Handler at the init)
	 * @param recipes {@link Recipe} Arrays
	 */
	public RecipeHandler(ArrayList<Recipe>... recipes) {add(recipes);}
	
	/**
	 * Get all Recipes of the Handler in a Array
	 */
	public Recipe[] getRecipes()
	{
		return recipes.toArray(new Recipe[recipes.size()]);
	}
	
	/**
	 * Reset the Recipes. Use with Caution
	 */
	public RecipeHandler reset()
	{
		recipes = new ArrayList<Recipe>();
		return this;
	}
	
	/**
	 * Add Recipes to the Handler
	 * @param recipes {@link Recipe}s to be added
	 */
	public RecipeHandler add(Recipe... recipes)
	{
		for (Recipe recipe: recipes)
			this.recipes.add(recipe);
		
		return this;
	}
	
	/**
	 * Add (A Lot of) Recipes to the Handler
	 * @param recipes {@link Recipe}s Arrays to be added
	 */
	public RecipeHandler add(Recipe[]... recipes)
	{
		for (Recipe[] recipeArray: recipes)
			for (Recipe recipe: recipeArray)
				this.recipes.add(recipe);
		
		return this;
	}
	
	/**
	 *  Add (A LOT of) Recipes to the Handler
	 *  @param recipes {@link ArrayList} of {@link Recipe}s to be added
	 */
	public RecipeHandler add(ArrayList<Recipe>... recipes)
	{
		for (ArrayList<Recipe> recipeList: recipes)
			for (Recipe recipe: recipeList)
				this.recipes.add(recipe);
		
		return this;
	}
	
	/**
	 * Add Recipes to the Handler, using a ICraftable to get the recipes.
	 * @param craftables {@link ICraftable}s to be added
	 */
	public RecipeHandler add(ICraftable... craftables)
	{
		for (ICraftable craftable: craftables)
			for (Recipe recipe : craftable.getRecipes())
				this.recipes.add(recipe);
		
		return this;
	}
	
	/**
	 * Filter Recipes from Handler based on a Tag
	 * @param tag {@link String} tag
	 * @param NotMode if true, only Recipes without the tag will stay
	 */
	public RecipeHandler filterTags(FilterMode mode, String... tags)
	{
		Recipe[] recipeBuffer = RecipeHelper.filterTags(getRecipes(), mode, tags);
		
		this.reset().add(recipeBuffer);
		
		return this;
	}
	
	/**
	 * Just call it and you are done.
	 */
	public RecipeHandler registerAll()
	{
		Recipe[] recipes = getRecipes();
		for (Recipe recipe: recipes) recipe.registerCrafting();
		
		return this;
	}
}
