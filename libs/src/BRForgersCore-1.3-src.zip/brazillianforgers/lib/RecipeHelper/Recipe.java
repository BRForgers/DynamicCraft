package brazillianforgers.lib.RecipeHelper;

import java.util.ArrayList;
import java.util.Arrays;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;

public class Recipe
{
	public enum RecipeType {FURNACE, SHAPED, SHAPELESS, IRECIPE, NONE;}
	
	//Common Recipe Values
	public ItemStack output;
	public RecipeType type;
	public String[] tags = {};
	
	//Shaped Recipes
	public String[] shapedRecipeFormat;
	public RecipeValue[] shapedRecipeInputs;
	
	//Shapeless Recipes
	public ItemStack[] shapelessInputs;
	
	//Furnace Recipe
	public ItemStack furnaceInput;
	public float furnaceXp;
	
	//IRecipe
	public IRecipe recipe;
	
	/**
	 * Shaped Recipe Definition
	 * @param output Item ({@link ItemStack}) Crafting output
	 * @param recipeForm Format of the Recipe
	 * @param inputs Values for the Recipe Format (RecipeValue[]) Inputs
	 */
	public Recipe(ItemStack output, String[] recipeForm, RecipeValue... inputs)
	{		this.type = RecipeType.SHAPED;
		this.output = output;
		this.shapedRecipeFormat = recipeForm;		
		this.shapedRecipeInputs = inputs;
	}
	
	/**
	 * Shapeless Recipe Definition
	 * @param output Item ({@link ItemStack}) Crafting output
	 * @param recipeForm Format of the Recipe
	 * @param inputs Items ({@link ItemStack}[]) used in Recipe
	 */
	public Recipe(ItemStack output, ItemStack... inputs)
	{		this.type = RecipeType.SHAPELESS;
		this.output = output;
		this.shapelessInputs = inputs;
	}
	
	/**
	 * Furnace Recipe Definition
	 * @param output Item ({@link ItemStack}) Crafting output
	 * @param recipeForm Format of the Recipe
	 * @param inputs Item ({@link ItemStack}) Inputs
	 */
	public Recipe(ItemStack input, ItemStack output, float xp)
	{		this.type = RecipeType.FURNACE;
		this.output = output;
		this.furnaceInput = input;
		this.furnaceXp = xp;
	}
	
	/**
	 * {@link IRecipe} Definition
	 * @param recipe Class that implements {@link IRecipe}
	 */
	public Recipe(IRecipe recipe)
	{		this.type = RecipeType.IRECIPE;
		this.recipe = recipe;
	}
	
	/**
	 * Empty Definition. You can manually define it.
	 */
	public Recipe()
	{this.type = RecipeType.NONE;}
	
	/**
	 * Add a Tag (a String) to the Tag Array
	 * @param tag String Tag
	 */
	public Recipe addTag(String tag)
	{
		if (!doHaveTag(tag)) this.tags[tags.length] = tag;
		
		return this;
	}
	
	/**
	 * Add Tags (in a String Array) to the Tag Array
	 * @param tag String Tag
	 */
	public Recipe addTags(String[] tags)
	{
		for(String tag: tags) addTag(tag);
		return this;
	}
	
	/**
	 * Test if have a Tag
	 * @param tag String Tag
	 */
	public boolean doHaveTag(String tag)
	{
		for(String eachTag: tags) if (eachTag == tag) return true;
		return false;
	}
	
	/**
	 * Remove a Tag from the Tag Array
	 * @param tag String Tag
	 */
	public void removeTag(String tag)
	{
		String[] newTags = {};
		for(int i = 0; i < tags.length; i++) if (tags[i] != tag) newTags[newTags.length] = tags[i];
	}
	
	/**
	 * Parse the Shaped Recipe Params.
	 * @return an Object Array to be used on the GameRegistry, or NULL if this is not a Shaped Recipe
	 */
	public Object[] parseShapedInput()
	{
		if (this.type != RecipeType.SHAPED) return null;
		
		//Starts Parsing a Recipe
		ArrayList<Object> parsed = new ArrayList<Object>();
		
		/* Adds the Recipe Form */
		parsed.addAll(Arrays.asList(shapedRecipeFormat));

		/* Adds the Recipe Values */
		for(int i = 0; i < shapedRecipeInputs.length; i++)
		{
			parsed.add(shapedRecipeInputs[i].id);
			parsed.add(shapedRecipeInputs[i].item);
		}
		
		return parsed.toArray();
	}
	
	/**
	 * Parse the Shapeless Recipe Params.
	 * @return an Object Array to be used on the GameRegistry, or NULL if this is not a Shapeless Recipe
	 */
	public Object[] parseShapelessInput()
	{
		if (this.type != RecipeType.SHAPELESS) return null;
		
		return shapelessInputs;
	}
	
	/**
	 * Register the Crafting defined for the Recipe
	 */
	public void registerCrafting()
	{
		/* Shaped Recipe */
		if (this.type == RecipeType.SHAPED) 
			recipe = GameRegistry.addShapedRecipe( output, parseShapedInput() );
		
		/* Shapeless Recipe */
		if (this.type == RecipeType.SHAPELESS)
			GameRegistry.addShapelessRecipe( output, parseShapelessInput() );
		
		/* Smelting Recipe */
		if (this.type == RecipeType.FURNACE)
			GameRegistry.addSmelting( furnaceInput, output, furnaceXp );
		
		/* IRecipe */
		if (this.type == RecipeType.IRECIPE)
			GameRegistry.addRecipe(recipe);
	}
}
