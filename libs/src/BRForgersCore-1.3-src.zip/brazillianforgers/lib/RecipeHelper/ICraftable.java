package brazillianforgers.lib.RecipeHelper;

/**
 * Any Class that Implements it can add Recipes to the Game
 * @author TheFreeHigh
 *
 */
public interface ICraftable
{
	public Recipe[] getRecipes();
}
