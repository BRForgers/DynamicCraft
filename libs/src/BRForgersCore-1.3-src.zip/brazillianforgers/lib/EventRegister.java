package brazillianforgers.lib;

import net.minecraftforge.common.MinecraftForge;

public class EventRegister
{
	public static void addEvents(Object... events)
	{
		for (Object event: events)
			MinecraftForge.EVENT_BUS.register(event);
	}
	
	public static void addTerrainGenEvents(Object... events)
	{
		for (Object event: events)
			MinecraftForge.TERRAIN_GEN_BUS.register(event);
	}
	
	public static void addOreGenEvents(Object... events)
	{
		for (Object event: events)
			MinecraftForge.ORE_GEN_BUS.register(event);
	}
}
