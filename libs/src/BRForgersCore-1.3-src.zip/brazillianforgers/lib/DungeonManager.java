package brazillianforgers.lib;

import brazillianforgers.lib.DungeonManager.DungeonChests.Groups;
import net.minecraft.item.ItemStack;
import net.minecraft.util.WeightedRandomChestContent;
import net.minecraftforge.common.ChestGenHooks;

/**
 * A Manager for Dungeon Loot. Use it on a CommonProxy or a Manager
 * @author brazillianforgers
 */
public class DungeonManager {
	/**
	 * Now all is in a Enum. Beautiful, huh?
	 * @author adrian
	 *
	 */
	public enum DungeonChests
	{
		BONUS_CHEST(ChestGenHooks.BONUS_CHEST),
		VILLAGE_BLACKSMITH(ChestGenHooks.VILLAGE_BLACKSMITH),
		DUNGEON_CHEST(ChestGenHooks.DUNGEON_CHEST),
		MINESHAFT_CORRIDOR(ChestGenHooks.MINESHAFT_CORRIDOR),
		PYRAMID_DESERT_CHEST(ChestGenHooks.PYRAMID_DESERT_CHEST),
		PYRAMID_JUNGLE_CHEST(ChestGenHooks.PYRAMID_JUNGLE_CHEST),
		PYRAMID_JUNGLE_DISPENSER(ChestGenHooks.PYRAMID_JUNGLE_DISPENSER),
		STRONGHOLD_CORRIDOR(ChestGenHooks.STRONGHOLD_CORRIDOR),
		STRONGHOLD_CROSSING(ChestGenHooks.STRONGHOLD_CROSSING),
		STRONGHOLD_LIBRARY(ChestGenHooks.STRONGHOLD_LIBRARY);
		
		public enum Groups
		{
			OVERWORLD(BONUS_CHEST,VILLAGE_BLACKSMITH),
			UNDERGROUND(DUNGEON_CHEST,MINESHAFT_CORRIDOR),
			PYRAMIDS(PYRAMID_DESERT_CHEST,PYRAMID_JUNGLE_CHEST,PYRAMID_JUNGLE_DISPENSER),
			STRONGHOLD(STRONGHOLD_CORRIDOR,STRONGHOLD_CROSSING,STRONGHOLD_LIBRARY);
			
			DungeonChests[] dChests;
			
			Groups(DungeonChests... chests)
			{
				dChests = chests;
			}
			
			public DungeonChests[] getChests()
			{
				return dChests;
			}
		}
		
		String chestValue = null;
		
		DungeonChests(String value)
		{
			chestValue = value;
		}
		
		public String getValue()
		{
			return chestValue;
		}
	}
	
	/**
	 * Add Loot to a Dungeon Chests
	 * @param chest A Chest from DungeonChests
	 * @param item the ItemStack to be added
	 * @param minAmount Minimum Amount of the Loot
	 * @param maxAmount Maximum Amount of the Loot
	 * @param chance The Chance (1=Rarest,100=Commonest) of the Loot
	 */
	public static void addChestLoot(DungeonChests chest, ItemStack item, int minAmount, int maxAmount, int chance)
	{
		ChestGenHooks.getInfo(chest.getValue()).addItem(new WeightedRandomChestContent(item, minAmount, maxAmount, chance));
	}
	
	/**
	 * Add Loot to a Dungeon Chests
	 * <br> {@link Deprecated}, Use the DungeonChests one
	 * @param id the the String of the Chest Loot (in the DungeonChest Array)
	 * @param item the ItemStack to be added
	 * @param minAmount Minimum Amount of the Loot
	 * @param maxAmount Maximum Amount of the Loot
	 * @param chance The Chance (1=Rarest,100=Commonest) of the Loot
	 */
	@Deprecated
	public static void addChestLoot(String id, ItemStack item, int minAmount, int maxAmount, int chance)
	{
		ChestGenHooks.getInfo(id).addItem(new WeightedRandomChestContent(item, minAmount, maxAmount, chance));
	}
	
	/**
	 * Add Loot to Multiple Dungeon Chests
	 * @param group One of the {@link Groups}. Add all Chests from the Group
	 * @param item the ItemStack to be added
	 * @param minAmount Minimum Amount of the Loot
	 * @param maxAmount Maximum Amount of the Loot
	 * @param chance The Chance (1=Rarest,100=Commonest) of the Loot
	 */
	public static void addChestLoot(Groups group, ItemStack item, int minAmount, int maxAmount, int chance)
	{
		WeightedRandomChestContent chest = new WeightedRandomChestContent(item, minAmount, maxAmount, chance);
		DungeonChests[] dungeonChests = group.getChests();
		
		for(DungeonChests dChest: dungeonChests)
		{
			ChestGenHooks.getInfo(dChest.getValue()).addItem(chest);
		}
	}
	
	/**
	 * Add Loot to Multiple Dungeon Chests
	 * @param group A Array of {@link DungeonChests}. All will get the Loot added.
	 * @param item the ItemStack to be added
	 * @param minAmount Minimum Amount of the Loot
	 * @param maxAmount Maximum Amount of the Loot
	 * @param chance The Chance (1=Rarest,100=Commonest) of the Loot
	 */
	public static void addChestLoot(DungeonChests[] dungeonChests, ItemStack item, int minAmount, int maxAmount, int chance)
	{
		WeightedRandomChestContent chest = new WeightedRandomChestContent(item, minAmount, maxAmount, chance);
		for(DungeonChests dChest: dungeonChests)
		{
			ChestGenHooks.getInfo(dChest.getValue()).addItem(chest);
		}
	}
	
	/**
	 * Add Loot to All Dungeon Chests
	 * @param item the ItemStack to be added
	 * @param minAmount Minimum Amount of the Loot
	 * @param maxAmount Maximum Amount of the Loot
	 * @param chance The Chance (1=Rarest,100=Commonest) of the Loot
	 */
	public static void addChestLootToAll(ItemStack item, int minAmount, int maxAmount, int chance)
	{
		WeightedRandomChestContent chest = new WeightedRandomChestContent(item, minAmount, maxAmount, chance);
		DungeonChests[] dungeonChests = DungeonChests.values();
		for(DungeonChests dChest: dungeonChests)
		{
			ChestGenHooks.getInfo(dChest.getValue()).addItem(chest);
		}
	}
}
