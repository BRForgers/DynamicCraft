package brazillianforgers.util;

import net.minecraft.init.Blocks;

public class IlluminBlocks
{
	public static void load()
	{
		Blocks.diamond_ore.setLightLevel(0.25f);
		Blocks.emerald_ore.setLightLevel(0.25f);
		Blocks.quartz_ore.setLightLevel(0.25f);
		Blocks.dragon_egg.setLightLevel(0.5f);
		Blocks.iron_ore.setLightLevel(0.125f);
		Blocks.command_block.setLightLevel(0.25f);
		Blocks.redstone_block.setLightLevel(0.25f);
		Blocks.end_portal.setLightLevel(1f);
		Blocks.end_portal_frame.setLightLevel(0.5F);
	}
}
