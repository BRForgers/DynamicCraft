package brazillianforgers.core;

/**
 * BRForgersCore's Strings Lib
 * @author BRForgers Team
 */
public class CoreLib
{
	//Mod Identity
	/**
	 * MODID of the Core
	 */
	public static final String MODID = "BRForgersCore";
	
	/**
	 * VERSION of the Core
	 */
	public static final String VERSION = "1.3";
	
	/**
	 * MODNAME of the Core
	 */
	public static final String MODNAME = "BRForgersCore";
	
	/**
	 * URL to Check for Updates
	 */
	public static final String UPDATEURL = "https://raw.githubusercontent.com/TheBrazillianForgersTeam/BRForgersCore/master/latest.txt";
	
	/* Add dependences="required-after:BRForgersCore@[1.3,)" in @Mod(...) to make the mod dependent on BRForgersCore */
}
