package brazillianforgers.core;

import org.apache.logging.log4j.Logger;

import cpw.mods.fml.common.FMLLog;
import cpw.mods.fml.common.Loader;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.common.config.Configuration;
import brazillianforgers.lib.*;
import brazillianforgers.util.*;

/**
 * BRForgersCore: Where a Lot of ~magic~ Definitions happen!
 * <br> The Core Mod itself define some variables for Common Mod Usage.
 * @author TheFreeHigh
 */
@Mod(modid = CoreLib.MODID , version = CoreLib.VERSION , name = CoreLib.MODNAME)
public class BRForgersCore
{
	@Instance(CoreLib.MODID)
	public static BRForgersCore instance;
	
	public static Logger logger = new SilentLogger();
	
	@EventHandler
	public static void preInit(FMLPreInitializationEvent e)
	{
		/* Get Logger */
		logger = e.getModLog();
		
		/* Startup Log */
		logger.info("I'm Alive?");
		FMLLog.info("Yup. You ARE. Now Load!");
		logger.info("Okay! Start Loading...");
		
		/* Get Configs */
		Configuration config = RandomUtils.getConfig(e);
		config.load();
		
		/// Start Modules ///
		
		/* Init CommonLib */
		CommonLib.init();
		
		/* Init IlluminBlocks */
		boolean illuminBlocks = config.getBoolean("illuminBlocks", "Modules", true, "Enable or Disable the IlluminBlocks Module, a Player Helper that adds light to certain blocks previously not.");
		if (illuminBlocks)
			IlluminBlocks.load();
		
		/* If we're in Client, load Client Modules */
		if (CommonLib.isClient)
		{			
			/* Init LiMI */
			logger.debug("Loading LiMI");
			boolean enableLiMI = config.getBoolean("enabledLiMI", "ClientModules", true, "Enable or Disable the Mod Indicator Module, based on Vazkii LiMI.");
			boolean forceLiMI = config.getBoolean("forceLiMI", "ClientModules", false, "Force the Mod Indicator to be enabled even when WAILA/LiMI is in the Game.");
			String formatting = config.getString("formatting", "ClientModules", "&9&o", "The formatting codes to use in the tooltip. Use & to substitute for the control character.");
			boolean isWAILA = Loader.isModLoaded("Waila");
			boolean isLiMI = Loader.isModLoaded("LiMI");
			if (enableLiMI && (!(isWAILA || isLiMI) || forceLiMI))
				EventRegister.addEvents(new ModIndicator(formatting));
		}
		
		/// End Modules ///
		
		/* Ending PreInit */
		
		if(config.hasChanged())
			config.save();
		
		logger.info("I think " + (CommonLib.isClient ? "we're" : "I'm") + " done for now.");
		if (CommonLib.isClient)
			logger.info("Also, Thanks "+ CommonLib.playername +", for playing with BRForgers Mods!");
		
		// I can't resist a Easter Egg..
		FMLLog.info("Uhh, such a Strange Core Mod. Okay, next Mods...");
	}
	
	@EventHandler
	public static void init(FMLInitializationEvent e)
	{
		logger.info("Look, it's Initialization Time!");
		logger.info("I just have nothing to do!");
	}
		
	@EventHandler
	public static void postInit(FMLPostInitializationEvent e)
	{
		logger.info("Oh, it's Post Initialization. Let's Check for Updates!");
		UpdateManager.UpdateStatus status = UpdateManager.check(CoreLib.UPDATEURL, CoreLib.VERSION);
		logger.info((status.connected) ? ((status.updated) ? "Yay! I'm Updated!" : "Ohh, I'm Outdated. The Latest Version is '" + status.version + "', and I'm still on '" + CoreLib.VERSION + "'. Please Update Me!") : "I can't get to Internet get the Remote Version. I'll assume I'm updated.");
	}
}
