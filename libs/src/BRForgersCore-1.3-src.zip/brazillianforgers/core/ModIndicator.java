package brazillianforgers.core;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import cpw.mods.fml.common.Loader;
import cpw.mods.fml.common.ModContainer;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.registry.GameData;

/**
 * A Slightly Modified version of LiMI, from Vazkii.
 * <br />Enabled when WAILA's not. (Or is Forced to)
 * @author TheFreeHigh, Vazkii
 *
 */
public class ModIndicator {
	
	String formatting;
	
	public ModIndicator(String formatting)
	{
		this.formatting = formatting.replaceAll("&", "\u00a7");
	}
	
	@SubscribeEvent
	public void onTooltip(ItemTooltipEvent event) {
		String itemName = GameData.getItemRegistry().getNameForObject(event.itemStack.getItem());
		ModContainer mod = Loader.instance().getIndexedModList().get(itemName.split(":")[0]);
		String name = (mod == null) ? "Minecraft" : mod.getName();
		event.toolTip.add(formatting + name);
	}
}
