package brazillianforgers.core;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Logger;

import brazillianforgers.lib.SilentLogger;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Loader;
import cpw.mods.fml.common.ModContainer;
import cpw.mods.fml.relauncher.Side;
import net.minecraft.client.Minecraft;

/**
 * BRForgersLib: A "Common" ObjectLib for Mod Interaction
 */
public class CommonLib
{
	public static void init()
	{
		CommonLib.isClient = (FMLCommonHandler.instance().getEffectiveSide() == Side.CLIENT);
		CommonLib.playername = CommonLib.isClient ? Minecraft.getMinecraft().getSession().getUsername() : "";
	}
	
	public Map<String, Boolean> booleans = new HashMap<String, Boolean>();
	public Map<String, String> strings = new HashMap<String, String>();
	public Map<String, Integer> integers = new HashMap<String, Integer>();
	public Map<String, Float> floats = new HashMap<String, Float>();
	
	public static boolean isClient = false;
	public static String playername = "";
	
	public static ModContainer[] getModsLoaded()
	{
		return Loader.instance().getModList().toArray(new ModContainer[Loader.instance().getModList().size()]);
	}
	
	public static boolean isModLoaded(String modname)
	{
		return Loader.isModLoaded(modname);
	}
}
