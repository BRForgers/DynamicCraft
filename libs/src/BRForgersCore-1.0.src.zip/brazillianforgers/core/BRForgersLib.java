package brazillianforgers.core;

import brazillianforgers.lib.ObjectStorage;

/**
 * BrazillianForgersLib: A "Common" ObjectLib for Mod Interaction
 */
public class BRForgersLib extends ObjectStorage{
	BRForgersLib() {super();}
}
