package brazillianforgers.core;

/**
 * BRForgersCore's Strings Lib
 * @author brazillianforgers
 */
public class CoreLib
{
	//Mod Identity
	public static final String MODID = "BRForgersCore";
	public static final String VERSION = "1.1";
	public static final String MODNAME = "BRForgersCore";
	
	/* Add dependences="required-after:BRForgersCore[1.1,2.0]" in @Mod(...) to make the mod dependent on BRForgersCore */
}
